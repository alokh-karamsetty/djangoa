from django.apps import AppConfig


class QuizapiConfig(AppConfig):
    name = 'quizapi'
